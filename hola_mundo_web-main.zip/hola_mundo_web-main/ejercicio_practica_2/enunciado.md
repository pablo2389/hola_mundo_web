# Enunciado desafío:
1- Para poder realizar este desafío debe haber completado los pasos del desafio anterior (crearse la cuenta en Github, realizar el Fork del repositorio de clase y haberlo descargado a su computadora).\
2- Ahora vamos a trabajar y modificar el archivo index.html que se encuentra dentro de esta carpeta.\
3- Abrir el archivo index.html que se encuentra dentro de esta carepta con nuestro editor de código (Visual Studio Code). Deberá ver contenido HTML que hemos dejado en dicho archivo para que usted utilice.\
4- Editr el archivo index.html, deberá editar el título ```h2``` para que muestre su nombre.
5- Abrir el archivo index.html que se encuentra en esta carpeta en su navegador web, deberá ver el contenido HTML reflejado en el navegador anunciando el "Hola Mundo web" y además deberá ver anunciado su nombre..\
6- Verificado que todo funciona como se espera, deberá subir el archivo index.html que usted modificó en su computadora a su repositorio de Github creado en su cuenta. Para eso recomendamos seguir el instructivo PDF y los videos tutoriales de Interfaz Github Web para poder "actualizar un repositorio" (subir sus cambios). 
7- Verificado que todo funciona como se espera, deberá subir al campus el link de su respositorio en el desafio correspondiente para así concluir la realización del mismo y verificar que sus cambios han impacatado en el respositorio como se espera.\

