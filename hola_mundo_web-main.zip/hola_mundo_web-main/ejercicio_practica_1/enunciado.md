# Enunciado desafío:
1- Primero deberá crearse una cuenta en Github siguiendo el instructivo PDF.\
2- Luego deberá realizar el Fork de este repositorio de clase que pertenece a INOVE. Le recomendamos seguir los instructivos PDF y los videos tutoriales sobre el uso de la Interfaz Github Web.\
3- Descargar el repositorio en su computadora como un ZIP y luego descomprimirlo. Recomendable tener en su computadora una carpeta destinada a almacenar todos los repositorios de este curso para mantener sus archivos en orden.\
4- Abrir la carpeta que se generó al extraer del ZIP en el editor de código (Visual Studio Code o VSC).\
5- Abrir el archivo index.html que se encuentra dentro de esta carepta con nuestro editor de código (Visual Studio Code). Deberá ver contenido HTML que hemos dejado en dicho archivo para que usted utilice.\
6- Abrir el archivo index.html que se encuentra en esta carpeta en su navegador web, deberá ver el contenido HTML reflejado en el navegador anunciando el "Hola Mundo web".\
7- Verificado que todo funciona como se espera, deberá subir al campus el link de su respositorio en el desafio correspondiente para así concluir la realización del mismo.\

