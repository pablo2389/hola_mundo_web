![Inove banner](inove.jpg)
Inove Escuela de Código\
info@inove.com.ar\
Web: [Inove](http://inove.com.ar)

__Ejemplos que el profesor mostrará en clase__\
ejemplos_clase/

ejercicios/

# Consultas
alumnos@inove.com.ar
